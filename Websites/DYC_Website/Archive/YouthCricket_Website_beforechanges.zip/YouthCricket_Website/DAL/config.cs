using System;
using System.Collections;
using System.Xml;
using System.Configuration;
using Lifeclinic.Security;

namespace Lifeclinic.Data.DAL
{
	/// <summary>
	/// Summary description for config.
	/// </summary>
	internal class CConfigHandler : IConfigurationSectionHandler
	{
		public virtual object Create(object oParent, object oCtx, XmlNode node)
		{
			CConfigDAL config;
			config = new CConfigDAL((CConfigDAL) oParent);
			config.LoadValues(node);
			return config;
		}
	}

	public class CConfigDAL
	{
		private Hashtable	m_collConns;
		private Hashtable	m_collActives;

		public CConfigDAL(CConfigDAL parent)
		{
			if (parent != null)
			{
				m_collConns = (Hashtable) parent.m_collConns.Clone();
				m_collActives = (Hashtable) parent.m_collActives.Clone();
			}
			else
			{
				m_collConns = new Hashtable();
				m_collActives = new Hashtable();
			}
		}

		internal void LoadValues(XmlNode node)
		{
			XmlAttributeCollection collAttr;
			XmlNode nodeSection;
			XmlNode nodeValue;
			int nCount;

			// get all the aliases
			nodeSection = node.SelectSingleNode("//aliases");
			nCount = nodeSection.ChildNodes.Count;
			CDESEncryptor cipher = new CDESEncryptor();
			for (int i = 0; i < nCount; i++)
			{
				nodeValue = nodeSection.ChildNodes.Item(i);
				if (nodeValue.NodeType != XmlNodeType.Element)
					continue;
				collAttr = nodeValue.Attributes;
				string strConnection;
				if (collAttr["cipher"].Value == "yes")
					strConnection = cipher.decrypt(collAttr["connection"].Value);
				else
					strConnection = collAttr["connection"].Value;

				string strAlias = collAttr["name"].Value;
				m_collConns[collAttr["name"].Value] = strConnection; 
			}

			// get all the databases
			nodeSection = node.SelectSingleNode("//databases");
			nCount = nodeSection.ChildNodes.Count;
			for (int i = 0; i < nCount; i++)
			{
				nodeValue = nodeSection.ChildNodes.Item(i);
				if (nodeValue.NodeType != XmlNodeType.Element || nodeValue.Name != "database")
					continue;
				collAttr = nodeValue.Attributes;
				m_collActives[collAttr["name"].Value] = collAttr["alias"].Value;
			}
		}

		public string getAliasConnString(string strAlias)
		{
			return (string) (m_collConns[strAlias]);
		}

		public string getActiveConnString(string strDatabase)
		{
			return getAliasConnString((string)m_collActives[strDatabase]);
		}

		public string getAliasFor(string strDatabase)
		{
			return (string) (m_collActives[strDatabase]);
		}
	}
}
