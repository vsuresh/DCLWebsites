﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Cricket;
using Cricket.Common;

namespace Cricket.Paypal
{
    public partial class payment : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
   }
}