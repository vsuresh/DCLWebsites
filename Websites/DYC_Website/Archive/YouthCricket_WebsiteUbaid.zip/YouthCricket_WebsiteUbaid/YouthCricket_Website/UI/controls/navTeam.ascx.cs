using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

namespace Cricket.controls
{

	/// <summary>
	///		Summary description for headerBase.
	/// </summary>
    public partial class navTeam : System.Web.UI.UserControl
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{

            if (!IsPostBack)
            {
                lblTeamName.Text = Session["teamName"] as string;
            
            }
		}

	}
}
