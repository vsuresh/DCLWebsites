using System;
using Cricket.BAL;
using Cricket.controls;

namespace Cricket.Teams
{
	/// <summary>
	/// Summary description for PageBase.
	/// </summary>
	public class PageBase : System.Web.UI.Page
	{
		protected BusinessLayer		m_bl;
		protected int				m_nTeamId;

		//todo:hard coded for now
		protected int		m_nTournamentId = 0;

		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);
			m_bl = new BusinessLayer();
			m_bl.open();

			//get the id's from session
			m_nTeamId = toInt(Session["team_id"]);

			//check if we have the team id
			if (m_nTeamId <= 0)
				Response.Redirect("../main/team_list.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}
		#endregion

		protected override void OnUnload(System.EventArgs e)
		{
			base.OnUnload(e);
			if (m_bl != null)
				m_bl.close();

		}

		//Helper methods
		protected int toInt(Object strDataObject)
		{
			if (strDataObject != null)
			{
				string strData = strDataObject.ToString();
				if (strData != null)
					if (strData.Length > 0)
						return int.Parse(strData);
			}
			return 0;
		}
		protected float toFloat(Object strDataObject)
		{
			if (strDataObject != null)
			{
				string strData = strDataObject.ToString();
				if (strData != null)
					if (strData.Length > 0)
						return float.Parse(strData);
			}
			return 0;
		}
		protected long toLong(string strData)
		{
			if (strData != null)
				if (strData.Length > 0)
					return long.Parse(strData);
			return 0;
		}
	}
}
