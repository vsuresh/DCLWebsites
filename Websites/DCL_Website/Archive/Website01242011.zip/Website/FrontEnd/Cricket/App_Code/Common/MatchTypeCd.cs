using System;
using System.Web.UI.WebControls;

namespace Cricket.Common
{
	/// <summary>
	/// Summary description for MatchTypeCd.
	/// </summary>
	public class MatchTypeCd
	{
		public static string getText(int nTypeCd)
		{
			string strType = "";
			switch(nTypeCd)
			{
				case 1:
					strType = "League";
					break;
				case 2:
					strType = "Final";
					break;
				case 3:
					strType = "SemiFinal 2";
					break;
				case 4:
					strType = "SemiFinal 1";
					break;
				case 5:
					strType = "Group A";
					break;
				case 6:
					strType = "Group B";
					break;
				case 7:
					strType = "Group C";
					break;
				case 8:
					strType = "Premier Division";
					break;
				case 9:
					strType = "Division A";
					break;
				case 10:
					strType = "QuaterFinal 1";
					break;
				case 11:
					strType = "Group D";
					break;
				case 12:
					strType = "QuaterFinal 2";
					break;
				case 13:
					strType = "QuaterFinal 3";
					break;
				case 14:
					strType = "QuaterFinal 4";
					break;
			}
			return strType;
		}

		public static string getGroup(int nTypeCd)
		{
			string strType = "";
			switch(nTypeCd)
			{
				case 5:
					strType = "A";
					break;
				case 6:
					strType = "B";
					break;
				case 7:
					strType = "C";
					break;
				case 8:
					strType = "Premier";
					break;
				case 9:
					strType = "A";
					break;
				case 11:
					strType = "D";
					break;
				default:
					strType = "-";
					break;
					
			}
			return strType;
		}

		public static void populateList(ref DropDownList ddl)
		{
			ddl.Items.Insert(0, new ListItem("QuaterFinal 4", "14"));
			ddl.Items.Insert(0, new ListItem("QuaterFinal 3", "13"));
			ddl.Items.Insert(0, new ListItem("QuaterFinal 2", "12"));
			ddl.Items.Insert(0, new ListItem("QuaterFinal 1", "10"));
			ddl.Items.Insert(0, new ListItem("Group D Match", "11"));
			ddl.Items.Insert(0, new ListItem("Group C Match", "7"));
			ddl.Items.Insert(0, new ListItem("Group B Match", "6"));
			ddl.Items.Insert(0, new ListItem("Group A Match", "5"));
			ddl.Items.Insert(0, new ListItem("SemiFinal 1 Match", "4"));
			ddl.Items.Insert(0, new ListItem("SemiFinal 2 Match", "3"));
			ddl.Items.Insert(0, new ListItem("Final Match", "2"));
			ddl.Items.Insert(0, new ListItem("League Match", "1"));
		}
	}
}
