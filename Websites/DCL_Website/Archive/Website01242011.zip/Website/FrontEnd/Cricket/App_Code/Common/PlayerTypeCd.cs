using System;
using System.Web.UI.WebControls;

namespace Cricket.Common
{
	/// <summary>
	/// Summary description for PlayerTypeCd.
	/// </summary>
	public class PlayerTypeCd
	{
		protected static string strFullText = "";
		protected static string strShortText = "";

		public static string getShortText(int nTypeCd)
		{
			getText(nTypeCd);
			return strShortText;
		}

		public static string getFullText(int nTypeCd)
		{
			getText(nTypeCd);
			return strFullText;
		}
	
		protected static void getText(int nTypeCd)
		{
			switch(nTypeCd)
			{
				case 3:
					strFullText = "Manager";
					strShortText = "(Mgr)";
					break;
				case 4:
					strFullText = "Vice Captain";
					strShortText = "(VC)";
					break;
				case 5:
					strFullText = "Captain";
					strShortText = "(C)";
					break;
				default:
					strFullText = "";
					strShortText = "";
					break;
			}
		}

		public static void populateList(ref DropDownList ddl)
		{
			ddl.Items.Add(new ListItem("Player", "0"));
			ddl.Items.Add(new ListItem("Captain", "5"));
			ddl.Items.Add(new ListItem("Vice Captain", "4"));
			ddl.Items.Add(new ListItem("Manager", "3"));
		}
	}

}
