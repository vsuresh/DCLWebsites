using System;

namespace Cricket.Common
{
	/// <summary>
	/// Summary description for MatchStatus.
	/// </summary>
	public class MatchStatus
	{
		public static int NotPlayed
		{
			get { return 0; }
		}
		public static int Tied
		{
			get { return -1; }
		}
	}
}
