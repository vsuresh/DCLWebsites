using System;
using Cricket;
using Cricket.BAL;
using Cricket.controls;

namespace Cricket
{
	/// <summary>
	/// Summary description for PageBase.
	/// </summary>
	public class PageBaseTournament : PageBase
	{
        protected int tournamentId = 0;
        protected string tournamentName = "None";

		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);

            if (!IsPostBack)
            {
                //check if we have the tournament id
                if (tournamentId <= 0)
                {
                    tournamentId = toInt(Session["tournament_id"]);
                    tournamentName = Session["tournament_name"] as string;
                    if (tournamentId <= 0)
                        Response.Redirect("/default.aspx");
                }
            }
		}


	}
}

