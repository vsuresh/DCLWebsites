using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Cricket;

namespace Cricket.Teams
{
	/// <summary>
	/// Summary description for matches.
	/// </summary>
	public partial class matches : PageBase
	{
	
		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);

			if (!IsPostBack)
			{
				loadData();
			}
		}

		protected void loadData()
		{
			SqlDataReader dr = m_bl.getMatchList(0, m_nTeamId);
			dgrid_matches.DataSource = dr;
			dgrid_matches.DataBind();
			dr.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dgrid_matches.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dgrid_matches_ItemCommand);
			this.dgrid_matches.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgrid_matches_ItemDataBound);

		}
		#endregion


		private void dgrid_matches_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
			{
				string strDate = e.Item.Cells[0].Text;
				int npos = strDate.IndexOf(" ");
				int nlen = strDate.Length - npos;
				e.Item.Cells[0].Text = strDate.Remove(npos, nlen);
			}
		}

		private void dgrid_matches_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if (e.CommandName == "View")
			{
				Session["match_id"] = e.Item.Cells[1].Text;
				Session["team1_id"] = e.Item.Cells[2].Text;
				Session["team2_id"] = e.Item.Cells[3].Text;
				Server.Transfer("match_score.aspx");
			}
		}
	}

}
