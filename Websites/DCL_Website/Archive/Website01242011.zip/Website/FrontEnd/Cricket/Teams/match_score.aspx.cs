using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Cricket;

namespace Cricket.Teams
{
	/// <summary>
	/// Summary description for match_score.
	/// </summary>
	public partial class match_score : PageBase
	{
	
		protected int			m_nMatchId;
		protected int			m_nTeam1Id;
		protected int			m_nTeam2Id;

		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);

			if (!IsPostBack)
			{
				m_nMatchId = toInt(Session["match_id"]);
				m_nTeam1Id = toInt(Session["team1_id"]);
				m_nTeam2Id = toInt(Session["team2_id"]);
				if (m_nMatchId <= 0)
					Server.Transfer("matches.aspx");

				loadData();
			}
		}

		protected void loadData()
		{
			//Team1 details
			SqlDataReader dr = m_bl.getTeamData(m_nTeam1Id);
			if (dr.Read())
			{
				lblTeamName1.Text = "Innings I: " + dr["name"].ToString();
			}
			dr.Close();

			dr = m_bl.getMatchBattingData(m_nMatchId, m_nTeam1Id);
			dgrid_batting.DataSource = dr;
			dgrid_batting.DataBind();
			dr.Close();

			dr = m_bl.getMatchStats(m_nMatchId, m_nTeam1Id);
			dgrid_summary.DataSource = dr;
			dgrid_summary.DataBind();
			dr.Close();

			dr = m_bl.getMatchBowlingData(m_nMatchId, m_nTeam1Id);
			dgrid_bowling.DataSource = dr;
			dgrid_bowling.DataBind();
			dr.Close();

			//Team2 details
			dr = m_bl.getTeamData(m_nTeam2Id);
			if (dr.Read())
			{
				lblTeamName2.Text = "Innings II: " + dr["name"].ToString();
			}
			dr.Close();

			dr = m_bl.getMatchBattingData(m_nMatchId, m_nTeam2Id);
			dgrid_batting2.DataSource = dr;
			dgrid_batting2.DataBind();
			dr.Close();

			dr = m_bl.getMatchStats(m_nMatchId, m_nTeam2Id);
			dgrid_summary2.DataSource = dr;
			dgrid_summary2.DataBind();
			dr.Close();

			dr = m_bl.getMatchBowlingData(m_nMatchId, m_nTeam2Id);
			dgrid_bowling2.DataSource = dr;
			dgrid_bowling2.DataBind();
			dr.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnReturn_Click(object sender, System.EventArgs e)
		{
			Server.Transfer("matches.aspx");
		}

		/*
		private void dgrid_batting_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
			{
				if (e.Item.Cells[1].Text == "1")
					e.Item.Cells[2].Text += " (captain)";
			}
		}

		private void dgrid_batting2_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
			{
				if (e.Item.Cells[1].Text == "1")
					e.Item.Cells[2].Text += " (captain)";
			}
		}*/
	}
}
