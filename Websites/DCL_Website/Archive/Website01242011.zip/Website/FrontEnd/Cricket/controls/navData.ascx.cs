using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

namespace Cricket.controls
{

	/// <summary>
	///		Summary description for headerBase.
	/// </summary>
	public partial class navData : System.Web.UI.UserControl
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			TeamName = Session["team_name"];
			
			Title = Session["tournament_name"];

			anchorAdmin.Text = "";
			if (Session["admin_sw"] != null)
			{
				string strAdminSw = Session["admin_sw"].ToString();
				if (strAdminSw == "1")
					anchorAdmin.Text = "Admin Section";
			}
		}

		public Object TeamName
		{
			set 
			{ 
				if (value != null)
					anchorTeamName.Text = value.ToString(); 
			}
		}

		public Object Title
		{
			set 
			{ 
				if (value != null)
					anchorTitle.Text = value.ToString(); 
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{

		}
		#endregion

	}
}
