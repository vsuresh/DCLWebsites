using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Mail;
using Cricket;
using Cricket.Common;
using Cricket;


namespace Cricket.Tournament
{
	/// <summary>
	/// Summary description for registration.
	/// </summary>
	public partial class registration : PageBaseTournament
	{
	
		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);

            if (!IsPostBack)
            {
                loadData();
                ViewState["tournament_id"] = tournamentId;

            }
            else
            {
                tournamentId = (int)ViewState["tournament_id"];
            }
		}

		protected void loadData()
		{
			clearData();
			populateTitle();

            DateTime? regStartDate = null;
            DateTime? regEndDate = null;
            SqlDataReader dr = m_bl.getTournamentData(tournamentId);
            if (dr.Read())
            {
                regStartDate = DataReaderHelper.GetDateTime(dr, "regstart_dt");
                regEndDate = DataReaderHelper.GetDateTime(dr, "regend_dt");
                lblFees.Text = dr["fees"].ToString();
            }
            dr.Close();

            if (regStartDate.HasValue)
                lblRegStartDate.Text = regStartDate.Value.ToLongDateString();
            if (regEndDate.HasValue)
                lblRegEndDate.Text = regEndDate.Value.ToLongDateString();

			if (DateTime.Now >= regStartDate && DateTime.Now <= regEndDate)
			{
                divRegOpen.Visible = true;
                divRegClose.Visible = false;
			}
			else
			{
                divRegOpen.Visible = false;
                divRegClose.Visible = true;
                if (DateTime.Now < regStartDate)
                {
                    divClosed.Visible = false;
                    divNotStarted.Visible = true;
                }
                else
                {
                    divClosed.Visible = true;
                    divNotStarted.Visible = false;
                }
            }

		}

		public void populateTitle()
		{
			ddlContact1Title.Items.Add(new ListItem("Captain", "Captain"));
			ddlContact1Title.Items.Add(new ListItem("Vice-Captain", "Vice-Captain"));
			ddlContact1Title.Items.Add(new ListItem("Manager", "Manager"));
			ddlContact1Title.Items.Add(new ListItem("Player", "Player"));
			ddlContact2Title.SelectedIndex = 0;

			ddlContact2Title.Items.Add(new ListItem("Captain", "Captain"));
			ddlContact2Title.Items.Add(new ListItem("Vice-Captain", "Vice-Captain"));
			ddlContact2Title.Items.Add(new ListItem("Manager", "Manager"));
			ddlContact2Title.Items.Add(new ListItem("Player", "Player"));
			ddlContact2Title.SelectedIndex = 1;
		
			ddlLocation.Items.Add(new ListItem("Plano", "Plano"));
			ddlLocation.Items.Add(new ListItem("Coppel", "Coppel"));
			ddlLocation.SelectedIndex = 0;
			
		}


		public void clearData()
		{
			txtContact1Name.Text = "";
			txtContact1Phone.Text = "";
			txtContact1Email.Text = "";

			txtContact2Name.Text = "";
			txtContact2Phone.Text = "";
			txtContact2Email.Text = "";

			txtTeamName.Text = "";
			txtComments.Text = "";

			lblMessage.Text = "";

		}

		protected void btnSubmit_Click(object sender, System.EventArgs e)
		{
			if (Page.IsValid)
			{
                if (txtTeamName.Text != "" && txtTeamName.Text != "")
                {
                    Guid regID = Guid.NewGuid();
                    m_bl.createTeamRegistration(regID, tournamentId, txtTeamName.Text, ddlLocation.SelectedValue,
                        txtContact1Name.Text, ddlContact1Title.SelectedValue, txtContact1Phone.Text, txtContact1Email.Text,
                        txtContact2Name.Text, ddlContact2Title.SelectedValue, txtContact2Phone.Text, txtContact2Email.Text,
                        txtComments.Text);

                    gotoPaypal(regID, txtTeamName.Text.Trim(), lblFees.Text.Trim());

                }
                else
                {
                    lblMessage.Text = "Team name or Fees is missing!";
                }
			}
		}

        private void gotoPaypal(Guid regId, string teamName, string fees)
        {
            Session["RegistrationID"] = regId;
            Session["Paypal_TeamName"] = teamName;
            Session["Paypal_Fees"] = fees;

            Response.Redirect("/paypal/payment.aspx");
        }


		private void SendEmail(string teamName, string toAddress)
		{
            try
            {
                string message = string.Format("This email is to confirm that we have received registration entry for your team {0} to participate in the {1}{2}{2}, Your registration is not final until you pay the regsiration fees on the website.", teamName, tournamentName, Environment.NewLine);
                MailMessage msg = new MailMessage();
                msg.Body = message;
                msg.From = "ziaq@dallascricket.net";
                msg.Bcc = "ziaq@dallascricket.net";
                msg.BodyFormat = MailFormat.Text;
                msg.Subject = string.Format("DCL: Registration confirmation for {0}", teamName);
                msg.Priority = MailPriority.Normal;
                msg.To = toAddress;
                SmtpMail.Send(msg);
            }
            catch
            {
            }
        }
		
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion
		
	}
}
