using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Cricket;


namespace Cricket.Tournament
{
	/// <summary>
	/// Summary description for ranking.
	/// </summary>
	public partial class ranking : PageBaseTournament
	{
		protected System.Web.UI.WebControls.Label lblError;
		
		protected int		m_nSerialNo = 1;
	
		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);

			if (!IsPostBack)
			{
				loadData();
			}
		}

		protected void loadData()
		{
			SqlDataReader dr = m_bl.getTeamStats(tournamentId);
			dgrid_teams.DataSource = dr;
			dgrid_teams.DataBind();
			dr.Close();

			dr = m_bl.getPenaltyAll(tournamentId);
			dgrid_penalty.DataSource = dr;
			dgrid_penalty.DataBind();
			dr.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dgrid_teams.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgrid_teams_ItemDataBound);

		}
		#endregion

		private void dgrid_teams_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
			{
				e.Item.Cells[0].Text = m_nSerialNo.ToString();
				m_nSerialNo++;

				foreach(TableCell item in e.Item.Cells)
				{
					if (item.Text == "&nbsp;")
						item.Text = "0";
				}

			}
		}


	}


}
