using System;
using System.Data.SqlClient;

namespace Cricket.DAL.Ground
{
	public class GetGroundList : Command
	{
		public GetGroundList(Connection conn) : base(conn)
		{
			m_cmd.CommandText = "select * from ground where active_sw = 1 order by name";
		}
	}
}
