﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using Cricket;

public partial class Rules : PageBase
{
    public static DataSet Defaults = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        Defaults = SelectDefaults();
        Cache["NewDataset"] = Defaults;
        lblDCL.Text = Defaults.Tables[2].Rows[0]["Description"].ToString();
    }

    public static DataSet SelectDefaults()
    {

        DataSet Dt = new DataSet();
        try
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dallascricketleague"].ConnectionString))
            {
                using (SqlCommand com = new SqlCommand("selectDefaults_sp", con))
                {
                    com.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    adapter.Fill(Dt);
                    return Dt;
                }
            }
        }
        catch (Exception)
        {
            return null;
        }
    }
}
