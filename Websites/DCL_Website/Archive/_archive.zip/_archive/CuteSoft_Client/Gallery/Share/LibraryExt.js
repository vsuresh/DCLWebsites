
function GalleryCreateDialog_Eval(Browser,Param,_wrapper,_elements,_scripts)
{
	//this function is not compatible with the www.javascriptobfuscator.com
	
	// service 
	function getcontent()
	{
		return _wrapper.getcontent();
	}
	function closedialog()
	{
		_wrapper.closedialog();
	}
	
	// event to be overrided
	function onclosedialog()
	{
		return true;
	}
	function onresizedialog()
	{
	}

	for(var i=0;i<_elements.length;i++)
	{
		eval("var "+_elements[i].id+"=_elements[i]");
	}
	
	for(var __i=0;__i<_scripts.length;__i++)
	{
		eval(_scripts[__i]);
	}
	
	return function(expr)
	{
		return eval(expr);
	}
}
